package game.enemyai

import game.enemyai.decisiontree.DecisionTreeValue
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.lo4_data_structures.trees.BinaryTreeNode
import game.maps.GridLocation
import game.{AIAction, MovePlayer}

import scala.collection.mutable
import game.lo4_data_structures.graphs
import game.lo4_data_structures.graphs.Graph


class AIPlayer(val id: String) {


  // TODO: Replace this placeholder code with your own
  def locatePlayer(playerId: String, playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {
    new PlayerLocation(1, 1, "Player1")
    var node = playerLocations
    while (node != null) {
      if (node.value.playerId == playerId) {
        return node.value
      }
      node = node.next
    }
    null
  }

  // TODO: Replace this placeholder code with your own
  def closestPlayer(playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {
    var playerX: PlayerLocation = new PlayerLocation(0, 0, "playerX")
    var node = playerLocations
    var inputPlayer: PlayerLocation = locatePlayer(id, playerLocations)
    var xxxx: Double = 999999999.99
    var x = inputPlayer.x
    var y = inputPlayer.y
    while (node.next != null) {
      var diffX = x - node.value.x
      var diffY = y - node.value.y
      var diffX2 = diffX * diffX
      var diffY2 = diffY * diffY
      var distance = Math.sqrt(diffX2 + diffY2)
      if (distance < xxxx) {
        xxxx = distance
        playerX = node.value
      }
      node = node.next
    }
    playerX
  }


  // TODO: Replace this placeholder code with your own
  def computePath(start: GridLocation, end: GridLocation): LinkedListNode[GridLocation] = {
    var GridLocation1: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](end, null)
    while (GridLocation1.value != start) {
      if (GridLocation1.value.x < start.x) {
        var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x + 1, GridLocation1.value.y)
        GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)
      } else if (GridLocation1.value.x > start.x) {
        var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x - 1, GridLocation1.value.y)
        GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)
      } else if (GridLocation1.value.y < start.y) {
        var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x, GridLocation1.value.y + 1)
        GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)
      } else if (GridLocation1.value.y > start.y) {
        var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x, GridLocation1.value.y - 1)
        GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)
      }
    }
    GridLocation1
  }


  // TODO: Replace this placeholder code with your own
  def makeDecision(gameState: AIGameState, decisionTree: BinaryTreeNode[DecisionTreeValue]): AIAction = {
    MovePlayer(this.id, Math.random() - 0.5, Math.random() - 0.5)
    if (decisionTree.value.check(gameState) < 0) {
      makeDecision(gameState, decisionTree.left)
    } else if (decisionTree.value.check(gameState) > 0) {
      makeDecision(gameState, decisionTree.right)
    } else {
      decisionTree.value.action(gameState)
    }
  }

  def distanceAvoidWalls(gameState: AIGameState, begin: GridLocation, finish: GridLocation): Int = {
    var gamestatetoGraph = gameState.levelAsGraph()
    var startID: Int = gameState.gridLocationToId(begin)
    var endID: Int = gameState.gridLocationToId(finish)
    var queue: mutable.Queue[Int] = new mutable.Queue[Int]()
    queue.enqueue(startID)
    var distance: Int = 0
    var PlayertoDistace:Map[Int, Int] = Map[Int,Int](startID -> 0)
    var visted:List[Int] = List[Int]()
      while(queue.nonEmpty) {
        val unvisted: Int = queue.dequeue()
        for (id <- gamestatetoGraph.adjacencyList(unvisted)) {
          //          var neighbor: List[Int] = gamestatetoGraph.adjacencyList(id)
          if (!visted.contains(id))
            queue.enqueue(id)
          visted = visted :+ id.toInt
          distance = distance + 1
          PlayertoDistace = PlayertoDistace + (id.toInt -> +1)
          //          if(visted.contains(endID))
          //            queue.enqueue(id)
          //            visted = visted :+ id
          //            distance = distance +1
          //            PlayertoDistace = PlayertoDistace + (endID -> +1)
        }
      }
    PlayertoDistace.getOrElse(endID,id.toInt)
//    PlayertoDistace.get(endID)
  }

  // TODO: Replace this placeholder code with your own
  def closestPlayerAvoidWalls(gameState: AIGameState): PlayerLocation = {
    closestPlayer(gameState.playerLocations)
  }

  // TODO: Replace this placeholder code with your own
  def getPath(gameState: AIGameState): LinkedListNode[GridLocation] = {
    computePath(locatePlayer(this.id, gameState.playerLocations).asGridLocation(), closestPlayerAvoidWalls(gameState).asGridLocation())
  }




}

