package tests

import game.enemyai.{AIPlayer, PlayerLocation}
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation
import org.scalatest._

import java.util

class Task1 extends FunSuite {

  val EPSILON: Double = 0.001

  def compareDoubles(d1: Double, d2: Double): Boolean = {
    Math.abs(d1 - d2) < EPSILON
  }

  test("locate player") {
    val player: AIPlayer = new AIPlayer("player1")

    var myList: LinkedListNode[PlayerLocation] = new LinkedListNode(new PlayerLocation(4.0, 4.0, "Player1"), null)
    myList = new LinkedListNode(new PlayerLocation(5.0, 5.0, "Player2"), myList)
    myList = new LinkedListNode(new PlayerLocation(6.0, 6.0, "Player3"), myList)
    myList = new LinkedListNode(new PlayerLocation(7.0, 7.0, "Player4"), myList)
    myList = new LinkedListNode(new PlayerLocation(8.0, 8.0, "Player5"), myList)

    val computed: PlayerLocation = player.locatePlayer("Player1", myList)
    assert(compareDoubles(computed.x, 4.0))
    assert(compareDoubles(computed.y, 4.0))
    assert(computed.playerId == "Player1")
  }
  test("closet player") {
    val player: AIPlayer = new AIPlayer("Player1")

    var myList: LinkedListNode[PlayerLocation] = new LinkedListNode(new PlayerLocation(4.0, 4.0, "Player1"), null)
    myList = new LinkedListNode(new PlayerLocation(6.0, 6.0, "Player2"), myList)
    myList = new LinkedListNode(new PlayerLocation(5.0, 5.0, "Player3"), myList)
    myList = new LinkedListNode(new PlayerLocation(7.0, 7.0, "Player4"), myList)
    myList = new LinkedListNode(new PlayerLocation(8.0, 8.0, "Player5"), myList)

    val computed: PlayerLocation = player.closestPlayer(myList)
    assert(compareDoubles(computed.x, 5.0))
    assert(compareDoubles(computed.y, 5.0))
    assert(computed.playerId == "Player3")
  }
  test("compute path") {
    val player: AIPlayer = new AIPlayer("Player1")

    val path: LinkedListNode[GridLocation] = player.computePath(new GridLocation(1, 1), new GridLocation(2, 2))
    assert(path.value.x == 1)
    assert(path.value.y == 1)

    var GridLocation1: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](new GridLocation(2, 2), null)

    var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x - 1, GridLocation1.value.y)
    GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)

    var GridLocation3: GridLocation = new GridLocation(GridLocation1.value.x, GridLocation1.value.y - 1)
    GridLocation1 = new LinkedListNode[GridLocation](GridLocation3, GridLocation1)

    assert(player.computePath(new GridLocation(1, 1), new GridLocation(2, 2)).value == new GridLocation(1, 1))
    assert(player.computePath(new GridLocation(1, 1), new GridLocation(2, 2)).next.value == new GridLocation(1, 2) || player.computePath(new GridLocation(1, 1), new GridLocation(2, 2)).next.value == new GridLocation(2, 1))
    assert(player.computePath(new GridLocation(1, 1), new GridLocation(2, 2)).next.next.value == new GridLocation(2, 2))

    //assert(GridLocation1.value == ((2,2),null)
    //assert(player.computePath(new GridLocation(1,1), new GridLocation(2,2)) == GridLocation1)


  }
  test("compute pathN") {
    val player: AIPlayer = new AIPlayer("Player1")

    val path: LinkedListNode[GridLocation] = player.computePath(new GridLocation(2,2), new GridLocation(1,1))
    assert(path.value.x == 2)
    assert(path.value.y == 2)

    var GridLocation1: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](new GridLocation(1,1), null)

    var GridLocation2: GridLocation = new GridLocation(GridLocation1.value.x + 1, GridLocation1.value.y)
    GridLocation1 = new LinkedListNode[GridLocation](GridLocation2, GridLocation1)

    var GridLocation3: GridLocation = new GridLocation(GridLocation1.value.x, GridLocation1.value.y + 1)
    GridLocation1 = new LinkedListNode[GridLocation](GridLocation3, GridLocation1)

    assert(player.computePath(new GridLocation(2, 2), new GridLocation(1,1)).next.next.value == new GridLocation(1,1))
    assert(player.computePath(new GridLocation(2, 2), new GridLocation(1,1)).next.value == new GridLocation(2,1) || player.computePath(new GridLocation(2,2), new GridLocation(1,1)).next.value == new GridLocation(1,2))
    assert(player.computePath(new GridLocation(2,2), new GridLocation(1,1)).value == new GridLocation(2,2))
  }
}
