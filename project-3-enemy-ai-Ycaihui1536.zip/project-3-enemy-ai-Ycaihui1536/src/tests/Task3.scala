package tests

import game.enemyai.{AIGameState, AIPlayer, PlayerLocation}
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation
import org.scalatest._

import java.util

class Task3 extends FunSuite {

  test("distance with no walls") {
    val player: AIPlayer = new AIPlayer("player 1")

    val gameState: AIGameState = new AIGameState()
    gameState.levelWidth = 10
    gameState.levelHeight = 10
    gameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(2.5, 3.8, "player 1"), null)
    gameState.wallLocations = List()

    val testCases: Map[List[GridLocation], Int] = Map(
      List(new GridLocation(1, 1), new GridLocation(2, 2)) -> 2,
      List(new GridLocation(1, 1), new GridLocation(2, 7)) -> 7,
      List(new GridLocation(9, 9), new GridLocation(5, 2)) -> 11,
      List(new GridLocation(8, 2), new GridLocation(7, 0)) -> 3,
      List(new GridLocation(1, 1), new GridLocation(1, 1)) -> 0,
      List(new GridLocation(2, 2), new GridLocation(1, 1)) -> 2
    )

    for ((input, expectedOutput) <- testCases) {
      val distance: Int = player.distanceAvoidWalls(gameState, input.head, input(1))
      assert(distance == expectedOutput)
    }
  }

  test("distance with walls") {
    val player: AIPlayer = new AIPlayer("player 1")

    val gameState: AIGameState = new AIGameState()
    gameState.levelWidth = 10
    gameState.levelHeight = 10
    gameState.playerLocations = new LinkedListNode[PlayerLocation](new PlayerLocation(2.5, 3.8, "player 1"), null)
    gameState.wallLocations = List(
      new GridLocation(2, 3),
      new GridLocation(2, 4),
      new GridLocation(2, 5),
      new GridLocation(2, 6),
      new GridLocation(2, 7),
      new GridLocation(3, 7),
      new GridLocation(4, 7),
      new GridLocation(5, 7),
      new GridLocation(6, 7),
      new GridLocation(6, 6),
      new GridLocation(6, 5),
      new GridLocation(6, 4),
      new GridLocation(5, 4)
    )

    val testCases: Map[List[GridLocation], Int] = Map(
      List(new GridLocation(1, 1), new GridLocation(2, 2)) -> 2,
      List(new GridLocation(5, 5), new GridLocation(5, 3)) -> 4,
      List(new GridLocation(3, 6), new GridLocation(3,8)) -> 14
    )

    for ((input, expectedOutput) <- testCases) {
      val distance: Int = player.distanceAvoidWalls(gameState, input.head, input(1))
      assert(distance == expectedOutput)
    }
  }
}
